import 'package:flutter_test/flutter_test.dart';
import 'package:qovarian/screens/auth/login_bloc.dart';

void main() {
  group('Password must have', () {
    String pass;
    LoginBloc bloc = LoginBloc();
    test('minimum of 6 characters', () {
      //ACT
      pass = "s12!S";

      //ARRANGE

      //ASSERT
      expect(bloc.passwordValidator(pass),
          'Password must have atleast 6 characters');
    });

    test('accept alpha numeric and special characters', () {
      //ACT
      pass = "Passowrd@!#\$";

      //ARRANGE

      //ASSERT
      expect(
          bloc.passwordValidator(pass), 'Password must have aleast 1 number');
    });

    test('maximum of 12  characters', () {
      //ACT
      pass = "PAajsidjsajs!@KjsdfhD";

      //ARRANGE

      //ASSERT
      expect(bloc.passwordValidator(pass),
          'Password cannot be more than 12 characters');
    });
  });
}
