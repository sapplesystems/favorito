cd android;
fastlane dev;