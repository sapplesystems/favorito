import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:qovarian/utils/common_colors.dart';

class BottomCommonSheet extends StatefulWidget {
  BottomCommonSheet({Key? key}) : super(key: key);

  @override
  _BottomCommonSheetState createState() => _BottomCommonSheetState();
}

class _BottomCommonSheetState extends State<BottomCommonSheet> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: size.width * 0.04),
      height: size.height * 0.18,
      width: size.width * 0.94,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(15), topRight: Radius.circular(15)),
          border: Border.all(
            color: borderColor,
          )),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: size.width * 0.008),
                child: Text(
                  'Rewards from Mercedes F1',
                  style: GoogleFonts.montserrat(
                      fontWeight: FontWeight.w600,
                      fontSize: size.width * 0.038,
                      color: highlightedText),
                ),
              ),
              Container(
                height: size.height * 0.041,
                width: size.width * 0.214,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: borderColor)),
                child: TextButton(
                    style: ButtonStyle(
                        overlayColor: MaterialStateColor.resolveWith(
                            (states) => blankSpace)),
                    onPressed: () {},
                    child: Text(
                      "Filter",
                      style: GoogleFonts.montserrat(
                          fontWeight: FontWeight.w600,
                          color: highlightedText,
                          fontSize: size.width * 0.038),
                    )),
              )
            ],
          ),
          Container(
            child: Text(
              "Let’s get sticky with rewards xcepteur sint occaecat cupidatat non proident.",
              style: GoogleFonts.montserrat(
                  color: normalText, fontSize: size.width * 0.038),
            ),
          )
        ],
      ),
    );
  }
}
