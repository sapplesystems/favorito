const String ACCESS_PARAM_KEY = "access_param_key";
const String PUSH_NOTIFICATION_KEY = "push_notification_key";

class AppParamStore {
  static final _client = AppParamStore._internal();

  AppParamStore._internal();

  factory AppParamStore() => _client;

  final Map<String, dynamic> mParamMap = Map();

  addParam(String key, dynamic value) {
    mParamMap.update(key, (update) => update, ifAbsent: () => value);
  }

  getParam(String key) {
    return mParamMap.containsKey(key) ? mParamMap[key] : null;
  }

  removeParam(String key) {
    mParamMap.remove(key);
  }

  clearParams() {
    mParamMap.clear();
  }
}
