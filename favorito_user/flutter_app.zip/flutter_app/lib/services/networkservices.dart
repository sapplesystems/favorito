import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:qovarian/app/bloc/qovarian_app_data.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/constants/app.dart';
import 'package:qovarian/utils/stringutils.dart';

class ApiClient {
  static final _client = ApiClient._internal();

  Dio? dio;

  BaseOptions? options;

  ApiClient._internal();

  factory ApiClient() => _client;

  Future<Response<T>> getAuthData<T>({
    required String path,
    required RequestOptions requestOptions,
  }) async {
    if (dio == null) initDio();
    return await dio!.get(path, options: requestOptions.options);
  }

  Future<Response> getAuthFile({
    required String path,
    required String? savePath,
    ProgressCallback? progressCallback,
    required RequestOptions requestOptions,
  }) async {
    if (dio == null) initDio();
    return await dio!.download(path, savePath, options: requestOptions.options);
  }

  Future<Response<T>> getData<T>({
    required String path,
    required RequestOptions requestOptions,
  }) async {
    if (dio == null) await initDio();
    return await dio!.get(path, options: requestOptions.options);
  }

  Future<Response<T>> postData<T>({
    required String path,
    required Map<String, dynamic> data,
    required RequestOptions requestOptions,
  }) async {
    if (dio == null) await initDio();
    var post = dio!.post<T>(path,
        data: json.encode(data), options: requestOptions.options);
    return post;
  }

  Future<Response<T>> postAuthDataEncoded<T>({
    required String path,
    required String data,
    required RequestOptions requestOptions,
  }) async {
    if (dio == null) await initDio();
    return dio!.post(path, data: data, options: requestOptions.options);
  }

  Future<Response<T>> postAuthData<T>(
      {required String path,
      required Map<String, dynamic> data,
      required RequestOptions requestOptions}) async {
    if (dio == null) await initDio();
    return dio!.post<T>(path,
        data: json.encode(data), options: requestOptions.options);
  }

  Future<Response<T>> postAuthFileData<T>({
    required String path,
    required FormData formData,
    required RequestOptions requestOptions,
  }) async {
    if (dio == null) await initDio();
    return dio!.post(path, data: formData, options: requestOptions.options);
  }

  Future<Response<T>> updateData<T>({
    required String url,
    required Map<String, dynamic> data,
    required RequestOptions requestOptions,
  }) async {
    if (dio == null) await initDio();

    return dio!
        .put(url, data: json.encode(data), options: requestOptions.options);
  }

  Future<Response<T>> updateAuthDataEncoded<T>(
      {required String path,
      required String data,
      required RequestOptions requestOptions}) async {
    if (dio == null) await initDio();

    return dio!.put(path, data: data, options: requestOptions.options);
  }

  Future<Response<T>> updateAuthData<T>(
      {required String path,
      required Map<String, dynamic> data,
      required RequestOptions requestOptions}) async {
    if (dio == null) await initDio();
    return dio!
        .put(path, data: json.encode(data), options: requestOptions.options);
  }

  Future<Response<T>> deleteAuthData<T>(
      {required String path,
      required Map<String, dynamic> data,
      required RequestOptions requestOptions}) async {
    if (dio == null) await initDio();
    return dio!
        .delete(path, data: json.encode(data), options: requestOptions.options);
  }

  Future<void> initDio({String? baseUrl}) async {
    options = BaseOptions(
        baseUrl: baseUrl ?? Config.baseUrl,
        connectTimeout: 30000,
        receiveTimeout: 30000,
        headers: {
          'Authorization': !QovarianAppData().authKey.isStrEmpty
              ? QovarianAppData().formattedAuthKey
              : "",
        });
    options!.headers.addAll(getDefaultHeaders());
    dio = Dio(options);
  }

  RequestOptions getAppOptions({String? baseUrl, required String path}) {
    RequestOptions options = new RequestOptions(
        baseUrl: baseUrl ?? Config.baseUrl,
        path: path,
        followRedirects: true,
        validateStatus: (status) {
          return status! < 500;
        },
        connectTimeout: 30000,
        receiveTimeout: 30000,
        headers: {
          'Authorization': getAuthKey(),
        });
    options.headers.addAll(getDefaultHeaders());
    return options;
  }

  String getAuthKey() {
    return QovarianAppData().authKey.isStrEmpty
        ? DEFAULT_AUTHTOKEN_OTHER
        : QovarianAppData().formattedAuthKey;
  }

  RequestOptions getAppNoAuthOptions({String? baseUrl, required String path}) {
    RequestOptions options = new RequestOptions(
      baseUrl: baseUrl ?? Config.baseUrl,
      path: path,
      followRedirects: true,
      validateStatus: (status) {
        return status! < 500;
      },
      connectTimeout: 30000,
      receiveTimeout: 30000,
    );
    options.headers.addAll(getDefaultHeaders());
    return options;
  }

  Map<String, dynamic> getApiHeaders() {
    Map<String, dynamic> headers = {
      'Authorization': getAuthKey(),
    };
    headers.addAll(ApiClient().getDefaultHeaders());
    return headers;
  }

  Map<String, dynamic> getDefaultHeaders() {
    String xSleId =
        "c943b054062bb499846e9888332933d0fe8acdb4fbdd84408c774a1c355bee66";
    return xSleId.isEmpty
        ? {}
        : {
            "x-sle-id": xSleId,
            "x-mock-match-request-headers": "x-sle-id",
            "x-mock-match-request-body": true,
            "Content-Type": "application/json"
          };
  }
}

extension RequestOptionUtils on RequestOptions {
  Options get options {
    return Options(
      method: this.method,
      sendTimeout: this.sendTimeout,
      receiveTimeout: this.receiveTimeout,
      extra: this.extra,
      headers: this.headers,
      responseType: this.responseType,
      contentType: this.contentType,
      validateStatus: this.validateStatus,
      receiveDataWhenStatusError: this.receiveDataWhenStatusError,
      maxRedirects: this.maxRedirects,
      requestEncoder: this.requestEncoder,
      responseDecoder: this.responseDecoder,
      listFormat: this.listFormat,
    );
  }
}

var userSleMap = {
  "testuser1": "c943b054062bb499846e9888332933d0fe8acdb4fbdd84408c774a1c355bee66",
  "testuser2": "eb1b1a49662ab18853f6aa3b860ba801e05302d28eb92634aa3bf96b298d1db9",
  "testuser3": "c63de51dfa85cb60de383c229b783c9d2d44463ab519ba7fb39b76de17e31f36",
  "testuser4": "",
};

var partySleMap = {
  "4586690167987255895": "c943b054062bb499846e9888332933d0fe8acdb4fbdd84408c774a1c355bee66",
  "3289090348677255895": "eb1b1a49662ab18853f6aa3b860ba801e05302d28eb92634aa3bf96b298d1db9",
  "5538090348567392345": "c63de51dfa85cb60de383c229b783c9d2d44463ab519ba7fb39b76de17e31f36",
  "2289394646567251907": "",
};