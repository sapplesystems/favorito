import 'dart:async';
import 'dart:io';

import 'package:path/path.dart';
import 'package:quiver/strings.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/constants/db.dart';
import 'package:sqflite/sqflite.dart';
import 'package:synchronized/synchronized.dart';

class DbClient {
  static final _dbclient = DbClient._internal();
  bool _didInitDb = false;
  final _lock = new Lock();

  DbClient._internal();

  factory DbClient() {
    return _dbclient;
  }

  Database? _currentDb;

  Database? getDb({String name = DB_NAME}) {
    return _currentDb;
  }

  Database? getSqfliteDb({String name = DB_NAME}) {
    return _currentDb;
  }

  Future<Database?> getDbByName(String name) async {
    if (!isEmpty(name)) {
      //make sure db exists
      String path = await _verifyPath(name.toUpperCase());
      Database sqflitedb = await openDatabase(
        path,
        version: DB_VERSION,
        onConfigure: (db) async {
          await db.execute("PRAGMA foreign_keys = ON");
        },
      );
      return sqflitedb;
    }
    return null;
  }

  Future<Database?> getReadOnlyDb(String name) async {
    if (!isEmpty(name)) {
      //make sure db exists
      String path = await _verifyPath(name.toUpperCase());
      Database sqflitedb = await openReadOnlyDatabase(path);
      return sqflitedb;
    }
    return null;
  }

  initCurrentDb({String name = DB_NAME}) async {
    String path = await _verifyPath(name.toUpperCase());

    if (_currentDb == null) {
      await _lock.synchronized(() async {
        if (_currentDb == null) {
          _currentDb = await openDatabase(path, version: DB_VERSION,
              onConfigure: (db) async {
            await db.execute("PRAGMA foreign_keys = ON");
          }, onCreate: (db, version) async {

          }, onOpen: (db) {
            Log.i("on current db open");
            _didInitDb = true;
          }, onUpgrade: (db, old, now) async {
            Log.i("on current db onUpgrade  ${old} with ${now}");
          }, onDowngrade: (db, old, now) {
            Log.i("on current db onDowngrade  ${old} with ${now}");
          });
        }
      });
      _didInitDb = true;
      Log.i("initialized the db");
    }
  }

  Future<bool> initDeleteDb() async {
    var databasePath = await getDatabasesPath();

    String path = join(databasePath, DB_NAME.toUpperCase());
    if (_currentDb?.path == path) {
      await _closeCurrentDb();
    }

    if (await new Directory(dirname(path)).exists()) {
      await deleteDatabase(path);
      return true;
    } else {
      // if its already deleted or database not yet created
      return true;
    }
  }

  close() async {
    await _closeCurrentDb();
    Log.i("closed all db connections");
  }

  _closeCurrentDb() async {
    if (_currentDb != null) {
      await _currentDb!.close();
    }
    _currentDb = null;
    _didInitDb = false;
  }

  Future<String> _verifyPath(String name) async {
    var databasePath = await getDatabasesPath();
    String path = join(databasePath, name);

    if (await new Directory(dirname(path)).exists()) {
      return path;
    } else {
      try {
        await new Directory(dirname(path)).create(recursive: true);
      } catch (e) {
        Log.e(e);
      }
    }
    return path;
  }
}
