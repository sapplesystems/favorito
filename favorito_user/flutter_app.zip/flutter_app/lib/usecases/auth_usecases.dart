import 'package:dio/dio.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/constants/apis.dart';
import 'package:qovarian/models/auth.dart';
import 'package:qovarian/repos/auth_repo.dart';
import 'package:qovarian/usecases/app_general.dart';

class LoginUseCase extends UseCase<AuthResponse> {
  const LoginUseCase(this.request);
  final AuthRequest request;
  @override
  Future<AuthResponse> build() async {
    Response response;
    try {
      response = await AuthRepo()
          .loginRequest(GetEndPoint("/login/").execute(), request.toJson());
      if (response.statusCode! > 200 && response.statusCode! < 300) {
        var jsonData = response.data;
        return AuthResponse.fromJson(jsonData);
      } else {
        throw QHttpException.from(response.data, response.statusCode!);
      }
    } on Exception catch (e) {
      throw QHttpException.fromException(e);
    }
  }
}
