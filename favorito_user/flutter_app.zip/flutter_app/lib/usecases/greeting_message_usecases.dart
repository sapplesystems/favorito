import 'package:dio/dio.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/constants/apis.dart';
import 'package:qovarian/models/app.dart';
import 'package:qovarian/models/auth.dart';
import 'package:qovarian/models/party_greeting_message.dart';
import 'package:qovarian/repos/auth_repo.dart';
import 'package:qovarian/repos/part_repo.dart';
import 'package:qovarian/usecases/app_general.dart';

class GetPartyUseCase extends UseCase<PartyModel> {
  String? partyId;

  GetPartyUseCase(this.partyId);

  @override
  Future<PartyModel> build() async {
    Response response;
    try {
      var endPoint =
          GetEndPoint("/personal-party/$partyId/personal-detail").execute();
      response = await PartyRepo().getPartyRequest(endPoint, {});
      if (response.statusCode == 200) {
        var jsonData = response.data;
        return PartyModel.fromJson(jsonData);
      } else {
        throw QHttpException.from(response.data, response.statusCode!);
      }
    } on Exception catch (e) {
      throw QHttpException.fromException(e);
    }
  }
}
