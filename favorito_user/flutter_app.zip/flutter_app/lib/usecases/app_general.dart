import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/constants/apis.dart';
import 'package:qovarian/constants/user_defaults.dart';
import 'package:qovarian/models/app.dart';
import 'package:qovarian/repos/user_repo.dart';
import 'package:qovarian/services/dbservice.dart';
import 'package:qovarian/services/shared_preferences.dart';

abstract class UseCase<T> {
  const UseCase();

  Future<T> execute() async {
    return build();
  }

  Future<T> build();
}

abstract class SyncUseCase<T> {
  T execute() {
    return build();
  }

  T build();
}

class DatabaseExistException implements Exception {
  String cause;

  DatabaseExistException(this.cause);
}

class AuthenticationException implements Exception {
  String cause;

  AuthenticationException(this.cause);
}

class GetEndPoint extends SyncUseCase<String> {
  final String endPoint;
  final String? baseUrl;

  GetEndPoint(this.endPoint, {this.baseUrl});

  @override
  String build() {
    String url = this.baseUrl ?? "";
    return url + this.endPoint;
  }
}

class QHttpException implements Exception {
  String? error;
  String detail;
  int code;
  dynamic errType;

  QHttpException(
      {this.error, required this.detail, required this.code, this.errType});

  @override
  String toString() {
    if (detail == null) return "Exception Occured";
    return "$code -- $error  -- $errType -- $detail";
  }

  factory QHttpException.info({required String message}) {
    return QHttpException(code: 200, detail: message);
  }

  factory QHttpException.error({required String message}) {
    return QHttpException(code: 400, detail: message);
  }

  factory QHttpException.from(dynamic jsonData, int statusCode) {
    if (jsonData is Map) {
      var errors = jsonData['errors'] as List?;
      if (errors != null && errors.isNotEmpty) {
        return QHttpException(
            code: statusCode,
            detail: errors.first['description'],
            error: errors.first['reasonCode'],
            errType: errors.first['source']);
      }
    }
    return QHttpException(code: statusCode, detail: "error unknown");
  }

  factory QHttpException.fromException(Exception error) {
    switch (error.runtimeType) {
      case DioError:
        return QHttpException.fromDio(error as DioError);
      case OSError:
        return QHttpException(
            error: error.toString(), detail: "os error", code: 400);
      case SocketException:
        return QHttpException(
            error: error.toString(),
            detail: "there seems to problem with internet connection",
            code: 400);
      case QHttpException:
        return error as QHttpException;
      default:
    }
    return QHttpException(
        error: error.toString(), detail: "unknown error", code: 400);
  }

  factory QHttpException.fromDio(DioError error) {
    switch (error.type) {
      case DioErrorType.connectTimeout:
        return QHttpException(
            error: error.message, detail: "connect timeout", code: 400);
      case DioErrorType.sendTimeout:
        return QHttpException(
            error: error.message, detail: "send timeout", code: 400);
      case DioErrorType.receiveTimeout:
        return QHttpException(
            error: error.message, detail: "receive timeout", code: 400);
      case DioErrorType.response:
        String err = "";
        if (error.response != null && error.response!.data is Map) {
          return QHttpException.from(
              error.response!.data, error.response!.statusCode!);
        }
        return QHttpException(error: error.message, detail: "error unknown", code: 400);
      case DioErrorType.cancel:
        return QHttpException(
            error: error.message, detail: "request cancelled", code: 400);
      default:
        Log.e(error);
        String err = "";
        if (error.error != null) {
          if (error.error.runtimeType == SocketException) {
            err = "please check your network connection and try again";
          } else {
            err = error.error.toString();
          }
        } else {
          err = "Unknown error";
        }
        return QHttpException(error: error.message, detail: err, code: 400);
    }
  }
}

class GetUserData extends UseCase<UserData?> {
  const GetUserData();

  @override
  Future<UserData?> build() async {
    String? userId = await GetUid().execute();
    if (userId != null) return await UserRepo().getUserData(uid: userId);
    return null;
  }
}

class SaveUserData extends UseCase<bool> {
  UserData data;

  SaveUserData(this.data);

  @override
  Future<bool> build() async {
    return await UserRepo().saveUserData(data);
  }
}

class GetUserDataNet extends UseCase<UserData> {
  const GetUserDataNet();

  @override
  Future<UserData> build() async {
    Response response;
    try {
      response =
          await UserRepo().getUserDataNet(GetEndPoint(API_USER).execute());
    } on Exception catch (e) {
      throw QHttpException.fromException(e);
    }
    if (response.statusCode == 200) {
      var jsonData = response.data;
      try {
        return UserData.fromJson(jsonData);
      } catch (e) {
        Log.e(e);
        throw e;
      }
    } else {
      throw QHttpException.from(response.data, response.statusCode!);
    }
  }
}

class UpdateUserDataNet extends UseCase<UserData> {
  UserData? userData;

  UpdateUserDataNet(this.userData);

  @override
  Future<UserData> build() async {
    Response response;
    try {
      response = await UserRepo().updateUserDataNet(
          GetEndPoint(API_USER).execute(), userData!.toJson());
      if (response.statusCode == 200) {
        var jsonData = response.data;
        return UserData.fromJson(jsonData);
      } else {
        throw QHttpException.from(response.data, response.statusCode!);
      }
    } on Exception catch (e) {
      throw QHttpException.fromException(e);
    }
  }
}

class SaveAuthKey extends UseCase<bool> {
  final String? apiKey;

  SaveAuthKey(this.apiKey);

  @override
  Future<bool> build() {
    return UserDefaults().setString(API_KEY, apiKey!);
  }
}

class GetAuthKey extends UseCase<String?> {
  @override
  Future<String?> build() {
    return UserDefaults().getString(API_KEY);
  }
}

class ClearAuthKey extends UseCase<bool> {
  @override
  Future<bool> build() {
    return UserDefaults().setString(API_KEY, "");
  }
}

class SaveUid extends UseCase<bool> {
  final String? uid;

  SaveUid(this.uid);

  @override
  Future<bool> build() {
    return UserDefaults().setString(PARTY_ID, uid!);
  }
}

class GetUid extends UseCase<String?> {
  @override
  Future<String?> build() {
    return UserDefaults().getString(PARTY_ID);
  }
}

class ClearUid extends UseCase<bool> {
  @override
  Future<bool> build() {
    return UserDefaults().setString(PARTY_ID, "");
  }
}

class DeleteDb extends UseCase<bool> {
  DeleteDb();

  @override
  Future<bool> build() async {
    return DbClient().initDeleteDb();
  }
}
