import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:qovarian/generated/intl/messages_all.dart';

class Localize {
  static Future<Localize> load(Locale locale) {
    final String name =
        locale.countryCode!.isEmpty ? locale.languageCode : locale.toString();
    final String localeName = Intl.canonicalizedLocale(name);

    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      return Localize();
    });
  }

  static Localize? of(BuildContext context) {
    return Localizations.of<Localize>(context, Localize);
  }

  String get appName =>
      Intl.message('QOVARIAN', name: 'appName', desc: "Name of the app");
}

class LocalizeDelegate extends LocalizationsDelegate<Localize> {
  const LocalizeDelegate();

  @override
  bool isSupported(Locale locale) => [
        'en',
      ].contains(locale.languageCode);

  @override
  Future<Localize> load(Locale locale) => Localize.load(locale);

  @override
  bool shouldReload(LocalizeDelegate old) => false;
}

class FallbackMaterialLocalisationsDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const FallbackMaterialLocalisationsDelegate();

  @override
  bool isSupported(Locale locale) => true;

  @override
  Future<MaterialLocalizations> load(Locale locale) =>
      DefaultMaterialLocalizations.load(locale);

  @override
  bool shouldReload(FallbackMaterialLocalisationsDelegate old) => false;
}
