import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qovarian/app/bloc/app_bloc.dart';
import 'package:qovarian/app/qovarian_app_routing_widget.dart';

class QovarianApp extends StatefulWidget {
  @override
  _QovarianAppState createState() => _QovarianAppState();
}

class _QovarianAppState extends State<QovarianApp> {
  Key key = new UniqueKey();
  QovarianAppBloc appBloc = QovarianAppBloc();

  @override
  void initState() {
    super.initState();
    initApp();
  }

  @override
  Widget build(BuildContext context) {
    return Provider<QovarianAppBloc>.value(
      value: appBloc,
      child: Container(
          key: key,
          child: WillPopScope(
            child: AppRoutingContainer(),
            onWillPop: () async {
              if (Platform.isAndroid) {
                if (Navigator.of(context).canPop()) {
                  return true;
                } else {
                  return true;
                }
              } else {
                return true;
              }
            },
          )),
    );
  }

  void initApp() async {
    await appBloc.init();
  }
}
