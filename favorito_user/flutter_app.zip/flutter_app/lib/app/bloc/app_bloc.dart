import 'package:flutter/widgets.dart';
import 'package:qovarian/app/bloc/qovarian_app_data.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/app/route/routes.dart';
import 'package:qovarian/screens/base/base_helper.dart';
import 'package:qovarian/services/dbservice.dart';
import 'package:qovarian/usecases/app_general.dart';
import 'package:qovarian/utils/stringutils.dart';
import 'package:rxdart/rxdart.dart';

class QovarianAppBloc implements BlocBase {
  GlobalKey<NavigatorState>? navigatorKey;
  CurrentRouteNavigatorObserver? currentNavObserver;
  BehaviorSubject<AppViewState> appViewStateStream =
      BehaviorSubject.seeded(AppViewState.none);

  init() async {
    QovarianAppData().authKey = await GetAuthKey().execute();
    QovarianAppData().init();
    checkUserLogin();
    await initDb();
    Config.init();
    initFcm();
  }

  initDb() async {
    await DbClient().initCurrentDb();
    return true;
  }

  logout() async {}

  @override
  void dispose() {
    DbClient().close();
    appViewStateStream.close();
  }

  getToken() async {}

  void initFcm() async {}

  void checkUserLogin() async {
    String? partyId = await GetUid().execute();
    if (partyId.isStrEmpty) {
      QovarianAppData().viewState = AppViewState.shouldLogIn;
      appViewStateStream.add(QovarianAppData().viewState);
    } else {
      QovarianAppData().viewState = AppViewState.allOk;
      appViewStateStream.add(QovarianAppData().viewState);
    }
  }
}
