import 'dart:io';

import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/app/configs/sentry_report.dart';
import 'package:qovarian/models/app.dart';
import 'package:qovarian/utils/stringutils.dart';
import 'package:rxdart/rxdart.dart';
import 'package:sentry/sentry.dart';

enum AppViewState {
  shouldLogIn,
  allOk,
  profileUpdate,
  none,
  forceUpdate,
  sessionTimeout
}

class QovarianAppData {
  static final _appClient = QovarianAppData._internal();

  QovarianAppData._internal();

  factory QovarianAppData() {
    return _appClient;
  }

  AppViewState viewState = AppViewState.none;
  UserData? _userData;

  UserData? get userData => _userData;

  set userData(UserData? userData) {
    _userData = userData;
    userDataSub.add(_userData);
  }

  BehaviorSubject<UserData?> userDataSub = BehaviorSubject.seeded(null);

  String? _apiKey = "";

  set authKey(String? authKey) {
    _apiKey = authKey;
    if (!_apiKey.isStrEmpty) {}
  }

  String? get authKey => _apiKey;

  String get formattedAuthKey => "Token $_apiKey";

  void init() {
    userDataSub = BehaviorSubject.seeded(null);
  }

  clear() {
    userData = null;
    _apiKey = null;
  }

  void setSentryConfig() {
    SentryReport().initSentryConfig(
        commonEvent: SentryEvent(
            logger: "mobile_app",
            environment: Config.environment,
            release: Config.packageInfo.version,
            extra: {
              'id': userData?.uid ?? " ",
              'username': userData?.firstName ?? "",
              'email': userData?.email ?? ""
            },
            tags: getExtraInfo()));
  }

  getExtraInfo() {
    return {
      "buildNumber": Config.packageInfo.buildNumber,
      "os": Platform.operatingSystem,
      "os version": Platform.operatingSystemVersion,
    };
  }

  void dispose() {
    userDataSub.close();
  }
}
