import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:qovarian/app/bloc/app_bloc.dart';
import 'package:qovarian/app/configurations.dart';
import 'package:qovarian/app/localize.dart';
import 'package:qovarian/app/route/routes.dart';
import 'package:qovarian/app/qovariantheme.dart';
import 'package:qovarian/screens/splash/splashscreen.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

const TAG = AppRoutingContainer;

class AppRoutingContainer extends StatefulWidget {
  @override
  _AppRoutingContainerState createState() => _AppRoutingContainerState();
}

class _AppRoutingContainerState extends State<AppRoutingContainer>
    with WidgetsBindingObserver {
  QConfigurations? _configurations;
  QNavObserver qNavObserver = QNavObserver();
  CurrentRouteNavigatorObserver currentNavObserver =
      CurrentRouteNavigatorObserver();
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();
  late QovarianAppBloc appBloc;
  Key key = new UniqueKey();
  AppLifecycleState? lastLifeCycleState;

  @override
  void initState() {
    WidgetsBinding.instance!.addObserver(this);
    _configurations = QConfigurations(
      theme: kDarkTheme,
    );
    appBloc = Provider.of<QovarianAppBloc>(context, listen: false);
    appBloc.navigatorKey = navigatorKey;
    appBloc.currentNavObserver = currentNavObserver;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      key: key,
      title: 'Qovarian',
      navigatorKey: navigatorKey,
      themeMode: ThemeMode.light,
      theme: kLightTTheme.data,
      debugShowCheckedModeBanner: false,
      darkTheme: kDarkTheme.data,
      localizationsDelegates: [
        //const LocalizeDelegate(),
        const FallbackMaterialLocalisationsDelegate(),
        AppLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalMaterialLocalizations.delegate
      ],
      supportedLocales: [
        const Locale('en'), // English
      ],
      home: Builder(
          builder: (context) => Splash(
                animationEffect: 'zoom-in',
                home: Container(),
                duration: 1500,
              )),
      routes: constructRouteMap(),
      navigatorObservers: [qNavObserver, currentNavObserver],
      onGenerateRoute: getRoute,
      onUnknownRoute: (RouteSettings settings) => MaterialPageRoute(
          builder: (builder) => Container(
                child: Container(
                  child: Center(
                    child: Text("unknown page"),
                  ),
                ),
              )),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance!.removeObserver(this);
    appBloc.dispose();
    super.dispose();
  }

  @override
  void reassemble() {
    super.reassemble();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.inactive:
        break;
      case AppLifecycleState.paused:
        break;
      case AppLifecycleState.resumed:
        break;
      case AppLifecycleState.detached:
        break;
    }
    lastLifeCycleState = state;
  }

  // ios device will not emit inactive state if some dialog pops up.
  bool checkIfNotInactive() {
    if (Platform.isAndroid) {
      return lastLifeCycleState != null &&
          lastLifeCycleState != AppLifecycleState.inactive;
    } else if (Platform.isIOS) {
      return true;
    }
    return true;
  }
}
