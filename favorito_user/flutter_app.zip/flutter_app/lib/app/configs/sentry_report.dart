import 'package:sentry/sentry.dart';

import 'build_config.dart';

const DSN = '';

class SentryReport {
  static final _client = SentryReport._internal();

  SentryReport._internal();

  factory SentryReport() => _client;

  initSentryConfig({SentryEvent? commonEvent}) async {
    await Sentry.init((options) {
      options.dsn = DSN;
      options.addEventProcessor((event, {hint}) {
        return event.copyWith(
          logger: commonEvent!.logger,
          environment: commonEvent.environment,
          release: commonEvent.release,
          user: commonEvent.user,
          tags: commonEvent.tags,
        );
      });
    });
  }

  sendReport({dynamic error, dynamic stackTrace}) async {
    if (error == null && stackTrace == null) return;
    try {
      var response =
          await Sentry.captureException(error, stackTrace: stackTrace);
      if (response != SentryId.empty()) {
        Log.d('Success! Event ID: $response');
      } else {
        Log.d('Failed to report to Sentry.io: $response');
      }
    } catch (e) {
      Log.d('Error while reporting to sentry: ${e.toString()}');
    }
  }
}
