import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class QovarianTheme {
  const QovarianTheme._(this.name, this.data);

  final String name;

//  final ThemeData data;
  final ThemeData data;
}

final QovarianTheme kLightTTheme =
    new QovarianTheme._('Light', _buildLightTheme());

final QovarianTheme kDarkTheme =
    new QovarianTheme._('Dark', _buildLightTheme());

TextTheme _buildLightTextTheme() {
  return GoogleFonts.questrialTextTheme(ThemeData.light().textTheme);
}

TextTheme _buildDarkTextTheme() {
  return GoogleFonts.questrialTextTheme(ThemeData.dark().textTheme);
}

ThemeData _buildLightTheme() {
  const Color primaryColor = Color(0xff1b3c59);
  const Color backgroundColor = const Color(0xfff2f2f2);
  final ThemeData base = new ThemeData.light();
  return base.copyWith(
    primaryColor: primaryColor,
    primaryColorDark: Color(0xff001630),
    buttonColor: primaryColor,
    indicatorColor: Colors.white,
    splashColor: Colors.white24,
    splashFactory: InkRipple.splashFactory,
    accentColor: primaryColor,
    canvasColor: Colors.white,
    scaffoldBackgroundColor: primaryColor,
    backgroundColor: backgroundColor,
    errorColor: const Color(0xfff1342f),
    dividerColor: const Color(0xffCEDEDE),
    buttonTheme: const ButtonThemeData(
      textTheme: ButtonTextTheme.primary,
    ),
  );
}
