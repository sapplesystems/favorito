import 'email_validator.dart';

bool isNullorBool(bool s) => (s != null) ? s : false;

extension StringUtils on String? {
  bool get isStrEmpty => this == null || this!.trim().length == 0;
}

bool isEmail(String email) {
  if (email.isStrEmpty) {
    return false;
  } else if (!EmailValidator.validate(email)) {
    return false;
  }
  return true;
}

bool isPhone(String phone) {
  if (phone.isStrEmpty) {
    return false;
  } else if (!PhoneValidator.validateMobile(phone)) {
    return false;
  }
  return true;
}
