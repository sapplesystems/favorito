import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/constants/app.dart';

String encodeMap(Map data) {
  return data.keys.map((key) => "$key=${data[key]}").join("&");
}

int boolToInt(bool value) {
  return (value != null)
      ? value
          ? 1
          : 0
      : 0;
}

bool intToBool(int value) {
  return (value != null)
      ? (value == 1)
          ? true
          : false
      : false;
}

bool resolveBool(bool value) {
  return (value != null) ? value : false;
}

Uint8List? decodeBase64Image(String base64) {
  try {
    if (base64.isNotEmpty) {
      RegExp exp = RegExp("^data:image\/[a-z]+;base64,");
      base64 = base64.replaceAll(exp, "");
      return base64Decode(base64);
    } else {
      return null;
    }
  } catch (e) {
    print(e);
    return null;
  }
}

String fileSize(size, {int round = 2, bool decimal = false}) {
  int divider = 1024;

  size = int.parse(size.toString());

  if (decimal) divider = 1000;

  if (size < divider) return "$size B";

  if (size < divider * divider && size % divider == 0)
    return "${(size / divider).toStringAsFixed(0)} KB";

  if (size < divider * divider)
    return "${(size / divider).toStringAsFixed(round)} KB";

  if (size < divider * divider * divider && size % divider == 0)
    return "${(size / (divider * divider)).toStringAsFixed(0)} MB";

  if (size < divider * divider * divider)
    return "${(size / divider / divider).toStringAsFixed(round)} MB";

  if (size < divider * divider * divider * divider && size % divider == 0)
    return "${(size / (divider * divider * divider)).toStringAsFixed(0)} GB";

  if (size < divider * divider * divider * divider)
    return "${(size / divider / divider / divider).toStringAsFixed(round)} GB";

  if (size < divider * divider * divider * divider * divider &&
      size % divider == 0)
    return "${(size / divider / divider / divider / divider).toStringAsFixed(0)} TB";

  if (size < divider * divider * divider * divider * divider)
    return "${(size / divider / divider / divider / divider).toStringAsFixed(round)} TB";

  if (size < divider * divider * divider * divider * divider * divider &&
      size % divider == 0) {
    return "${(size / divider / divider / divider / divider / divider).toStringAsFixed(0)} PB";
  } else {
    return "${(size / divider / divider / divider / divider / divider).toStringAsFixed(round)} PB";
  }
}

/// A pair of values.
class Pair<E, F> {
  E first;
  F last;

  Pair(this.first, this.last);
}

Future<bool> isOnline() async {
  try {
    final result = await InternetAddress.lookup('google.com');
    if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
      return true;
    } else {
      return false;
    }
  } on SocketException catch (_) {
    return false;
  } on HandshakeException catch (_) {
    return false;
  }
}

Future<String> getAppPath() async {
  Directory dir = await getApplicationDocumentsDirectory();
  return dir.path;
}

int toInt(Object? value, {int defaultValue = defaultInt}) {
  int number = defaultValue;
  if (value != null) {
    try {
      number = toDouble(value).toInt();
    } on Exception catch (e) {
      Log.e(e);
    }
  }
  return number;
}

///Parse to double or returns [defaultValue]
///
double toDouble(Object? value, {double defaultValue = defaultDouble}) {
  double number = defaultDouble;
  if (value != null) {
    try {
      number = double.parse('$value');
    } on Exception catch (e) {
      Log.e(e);
    }
  }
  return number;
}

extension numutils on num {
  String get withPad => this.toString().padLeft(2, '0');
}

extension SinkUtils<T> on StreamController<T?> {
  void addIfNotClosed(T? data) {
    if (!this.isClosed) {
      add(data);
    }
  }
}

extension MapExtensions on Map {
  /// Reads a [key] value of [bool] type from [Map].
  ///
  /// If value is NULL or not [bool] type return default value [defaultBool]
  ///
  bool getBool(String key, {bool defaultValue = defaultBool}) {
    Map data = this;
    if (data == null) {
      data = defaultMap;
    }
    if (data.containsKey(key)) if (data[key] is bool)
      return this[key] ?? defaultValue;
    return defaultValue;
  }

  /// Reads a [key] value of [int] type from [Map].
  ///
  /// If value is NULL or not [int] type return default value [defaultInt]
  ///
  int getInt(String key, {int defaultValue = defaultInt}) {
    Map data = this;
    if (data == null) {
      data = defaultMap;
    }
    if (data.containsKey(key)) return toInt(data[key]);
    return defaultValue;
  }

  /// Reads a [key] value of [double] type from [Map].
  ///
  /// If value is NULL or not [double] type return default value [defaultDouble]
  ///
  double getDouble(String key, {double defaultValue = defaultDouble}) {
    Map data = this;
    if (data == null) {
      data = defaultMap;
    }
    if (data.containsKey(key)) return toDouble(data[key]);
    return defaultValue;
  }

  /// Reads a [key] value of [String] type from [Map].
  ///
  /// If value is NULL or not [String] type return default value [defaultString]
  ///.
  String getString(String key, {String defaultValue = defaultString}) {
    Map data = this;
    if (data == null) {
      data = defaultMap;
    }
    if (data.containsKey(key)) {
      if (data[key] == defaultString) return defaultValue;
      return '${data[key]}';
    }
    return defaultValue;
  }

  /// Reads a [key] value of [List] type from [Map].
  ///
  /// If value is NULL or not [List] type return empty List[defaultList]
  ///
  List getList(String key) {
    Map data = this;
    if (data == null) {
      data = defaultMap;
    }
    if (data.containsKey(key)) if (data[key] is List)
      return data[key] ?? defaultList;

    return defaultList;
  }

  /// Reads a [key] value of [List] type from [Map].
  ///
  /// If value is NULL or not [List] type return default value [defaultString]
  ///
  Map getMap(String key) {
    Map data = this;
    if (data == null) {
      data = defaultMap;
    }
    if (data.containsKey(key)) if (data[key] is Map)
      return data[key] ?? defaultMap;
    return defaultMap;
  }

  ///Add value to map if value is not null
  ///
  T? add<T>({required String key, required T value}) =>
      this.putIfAbsent(key, () => value);

  ///Map to JSON using[json.encode]
  ///
  String toJson() {
    String data = "{}";
    try {
      data = json.encode(this);
    } catch (e, s) {
      Log.e("Error in toJson\n\n *$this* \n\n $e\n\n$s");
    }
    return data;
  }

  ///Convert map to a String withIndent
  ///
  String toPretty() {
    String data = defaultString;
    try {
      JsonEncoder encoder = new JsonEncoder.withIndent('  ', toEncodable);
      data = encoder.convert(this);
    } catch (e, s) {
      Log.e("Error in toPretty\n\n *$this* \n\n $e\n\n$s");
    }
    return data;
  }
}

toEncodable(object) {
  if (object is String ||
      object is num ||
      object is Map ||
      object is List ||
      object is bool) return object;
  return '$object';
}
