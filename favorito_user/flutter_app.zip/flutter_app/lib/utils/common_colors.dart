import 'package:flutter/material.dart';

const normalText = Color(0xFF14242D);
const highlightedText = Color(0xFF333333);
const borderColor = Color(0xFF979797);
const blankSpace = Color(0xFFD8D8D8);