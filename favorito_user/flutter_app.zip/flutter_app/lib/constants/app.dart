

const String SENTRY_DSN = '';


const String DEFAULT_AUTHTOKEN_OTHER =
    "Token eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2MjkxMTY3MTEsImlhdCI6MTU5NzU4MDcxMSwidG9rZW4iOiIzNGNjM2Q3My1jZTdmLTRkOTgtOTljNy1mYmU1MDg5NmZlOTcifQ.Z8LZ3mL_OmgrK2jkAyNV2oOxZEqqf-pFHvv7RgRNYlQ";


const bool defaultBool = false;
const int defaultInt = 0;
const double defaultDouble = 0.0;
const String defaultString = '';
const Map defaultMap = {};
const List defaultList = [];

const UNKNOWN_ERROR = "Unknown Error";
