const String AUTHORIZATION = "Authorization";

const String API_SERVER1 = "/s1";

const String API_VERSION1 = "/v1";

const String API_PATH1 = API_SERVER1 + API_VERSION1;

const String API_LOGIN = API_PATH1 + "/login/";

const String API_LOGOUT = API_PATH1 + "/auth/logout/";

const String API_USER = API_PATH1 + "/auth/user/";
