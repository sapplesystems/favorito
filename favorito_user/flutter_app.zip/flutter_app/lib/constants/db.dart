const String DB_NAME = "qovarian.db";

final int DB_VERSION = 1;
