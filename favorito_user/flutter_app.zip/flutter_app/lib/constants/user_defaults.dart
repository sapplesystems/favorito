const String API_KEY = "api_key";
const String PARTY_ID = "party_id";

const String IS_FIRST_TIME = "is_first_time";