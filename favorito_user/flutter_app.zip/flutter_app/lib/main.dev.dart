import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/app/qovarian_root.dart';
import 'app/configs/sentry_report.dart';

Future<Null> _reportError(dynamic error, dynamic stackTrace) async {
  Log.e('Caught error: $error');

  if (!kReleaseMode) {
    Log.e(stackTrace);
    Log.e('In dev mode. Not sending report to Sentry.io.');
    return;
  }
  SentryReport().sendReport(error: error, stackTrace: stackTrace);
  Log.e("sentry", error, stackTrace);
}

Future<Null> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Config.buildType = BUILD_TYPE.DEV;

  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  LicenseRegistry.addLicense(() async* {
    final license = await rootBundle.loadString('google_fonts/OFL.txt');
    yield LicenseEntryWithLineBreaks(['google_fonts'], license);
  });

  FlutterError.onError = (FlutterErrorDetails details) async {
    if (!kReleaseMode) {
      FlutterError.dumpErrorToConsole(details);
    } else {
      Zone.current.handleUncaughtError(details.exception, details.stack!);
    }
  };

  runZonedGuarded<Future<Null>>(() async {
    SystemChrome.setPreferredOrientations(
        [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.light);

    runApp(new QovarianApp());
  }, (error, stackTrace) async {
    await _reportError(error, stackTrace);
  });
}
