// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AuthResponse _$AuthResponseFromJson(Map<String, dynamic> json) {
  $checkKeys(json, disallowNullValues: const ['partyId']);
  return AuthResponse(
    partyId: json['partyId'] as String,
    partyType: json['partyType'] as String?,
  );
}

Map<String, dynamic> _$AuthResponseToJson(AuthResponse instance) {
  final val = <String, dynamic>{
    'partyId': instance.partyId,
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull('partyType', instance.partyType);
  return val;
}

AuthRequest _$AuthRequestFromJson(Map<String, dynamic> json) {
  return AuthRequest(
    username: json['username'] as String,
    password: json['password'] as String?,
  );
}

Map<String, dynamic> _$AuthRequestToJson(AuthRequest instance) {
  final val = <String, dynamic>{
    'username': instance.username,
  };

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull('password', instance.password);
  return val;
}
