// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'party_greeting_message.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PartyModel _$PartyModelFromJson(Map<String, dynamic> json) {
  return PartyModel(
    partyId: json['partyId'] as String?,
    partytype: json['partytype'] as String?,
    personalDetail: json['personalDetail'] == null
        ? null
        : PersonalDetail.fromJson(
            json['personalDetail'] as Map<String, dynamic>),
  );
}

Map<String, dynamic> _$PartyModelToJson(PartyModel instance) {
  final val = <String, dynamic>{};

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull('partyId', instance.partyId);
  writeNotNull('partytype', instance.partytype);
  writeNotNull('personalDetail', instance.personalDetail);
  return val;
}

PersonalDetail _$PersonalDetailFromJson(Map<String, dynamic> json) {
  return PersonalDetail(
    firstName: json['firstName'] as String?,
    middleName: json['middleName'],
    lastName: json['lastName'] as String?,
    honorificPrefix: json['honorificPrefix'] as String?,
    honorificSuffix: json['honorificSuffix'] as String?,
    salutation: json['salutation'] as String?,
    preferredName: json['preferredName'] as String?,
  );
}

Map<String, dynamic> _$PersonalDetailToJson(PersonalDetail instance) =>
    <String, dynamic>{
      'firstName': instance.firstName,
      'middleName': instance.middleName,
      'lastName': instance.lastName,
      'honorificPrefix': instance.honorificPrefix,
      'honorificSuffix': instance.honorificSuffix,
      'salutation': instance.salutation,
      'preferredName': instance.preferredName,
    };
