import 'package:json_annotation/json_annotation.dart';

part 'app.g.dart';

@JsonSerializable(anyMap: true, includeIfNull: false)
class UserData {
  @JsonKey(name: 'first_name')
  String? firstName;
  @JsonKey(name: 'email')
  String? email;
  @JsonKey(name: 'uid')
  String? uid;
  @JsonKey(name: 'mobile_number')
  String? mobileNumber;
  @JsonKey(name: 'country_code')
  String? countryCode;
  String? dob;
  @JsonKey(name: 'profile_image')
  String? userImageUrl;
  @JsonKey(name: 'notification_id')
  String? notificationId;
  @JsonKey(name: 'notification_enabled')
  bool? notificationEnabled;

  String? city;
  String? country;
  @JsonKey(name: "device_id")
  String? deviceId;
  @JsonKey(name: "build_ver")
  String? buildVer;
  @JsonKey(name: "build_number")
  int? buildNumber;
  String? model;
  String? os;
  @JsonKey(name: "os_version")
  String? osVersion;
  @JsonKey(name: "timezone")
  String? timezone;
  @JsonKey(name: "debugging")
  bool? debugging;

  UserData({
    this.firstName,
    this.email,
    this.userImageUrl,
    this.uid,
    this.mobileNumber,
    this.countryCode,
    this.dob,
    this.notificationId,
    this.notificationEnabled,
    this.city,
    this.country,
    this.deviceId,
    this.buildVer,
    this.model,
    this.os,
    this.osVersion,
    this.timezone,
    this.debugging,
    this.buildNumber,
  });

  factory UserData.fromJson(Map<String, dynamic> json) =>
      _$UserDataFromJson(json);

  Map<String, dynamic> toJson() => _$UserDataToJson(this);

  String getPhoneNoWithCc() => countryCode! + mobileNumber!;
}

@JsonSerializable(anyMap: true)
class DemoPartyModel {
  String partyId;
  String? firstName;
  String? middleName;
  String? lastName;
  String? honorificPrefix;
  String? honorificSuffix;
  String? salutation;
  String? preferredName;

  DemoPartyModel(
      {required this.partyId,
      this.firstName,
      this.middleName,
      this.lastName,
      this.honorificPrefix,
      this.honorificSuffix,
      this.salutation,
      this.preferredName});

  factory DemoPartyModel.fromJson(Map<String, dynamic> json) =>
      _$DemoPartyModelFromJson(json);

  Map<String, dynamic> toJson() => _$DemoPartyModelToJson(this);
}
