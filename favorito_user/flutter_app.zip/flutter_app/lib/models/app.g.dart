// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UserData _$UserDataFromJson(Map json) {
  return UserData(
    firstName: json['first_name'] as String?,
    email: json['email'] as String?,
    userImageUrl: json['profile_image'] as String?,
    uid: json['uid'] as String?,
    mobileNumber: json['mobile_number'] as String?,
    countryCode: json['country_code'] as String?,
    dob: json['dob'] as String?,
    notificationId: json['notification_id'] as String?,
    notificationEnabled: json['notification_enabled'] as bool?,
    city: json['city'] as String?,
    country: json['country'] as String?,
    deviceId: json['device_id'] as String?,
    buildVer: json['build_ver'] as String?,
    model: json['model'] as String?,
    os: json['os'] as String?,
    osVersion: json['os_version'] as String?,
    timezone: json['timezone'] as String?,
    debugging: json['debugging'] as bool?,
    buildNumber: json['build_number'] as int?,
  );
}

Map<String, dynamic> _$UserDataToJson(UserData instance) {
  final val = <String, dynamic>{};

  void writeNotNull(String key, dynamic value) {
    if (value != null) {
      val[key] = value;
    }
  }

  writeNotNull('first_name', instance.firstName);
  writeNotNull('email', instance.email);
  writeNotNull('uid', instance.uid);
  writeNotNull('mobile_number', instance.mobileNumber);
  writeNotNull('country_code', instance.countryCode);
  writeNotNull('dob', instance.dob);
  writeNotNull('profile_image', instance.userImageUrl);
  writeNotNull('notification_id', instance.notificationId);
  writeNotNull('notification_enabled', instance.notificationEnabled);
  writeNotNull('city', instance.city);
  writeNotNull('country', instance.country);
  writeNotNull('device_id', instance.deviceId);
  writeNotNull('build_ver', instance.buildVer);
  writeNotNull('build_number', instance.buildNumber);
  writeNotNull('model', instance.model);
  writeNotNull('os', instance.os);
  writeNotNull('os_version', instance.osVersion);
  writeNotNull('timezone', instance.timezone);
  writeNotNull('debugging', instance.debugging);
  return val;
}

DemoPartyModel _$DemoPartyModelFromJson(Map json) {
  return DemoPartyModel(
    partyId: json['partyId'] as String,
    firstName: json['firstName'] as String?,
    middleName: json['middleName'] as String?,
    lastName: json['lastName'] as String?,
    honorificPrefix: json['honorificPrefix'] as String?,
    honorificSuffix: json['honorificSuffix'] as String?,
    salutation: json['salutation'] as String?,
    preferredName: json['preferredName'] as String?,
  );
}

Map<String, dynamic> _$DemoPartyModelToJson(DemoPartyModel instance) =>
    <String, dynamic>{
      'partyId': instance.partyId,
      'firstName': instance.firstName,
      'middleName': instance.middleName,
      'lastName': instance.lastName,
      'honorificPrefix': instance.honorificPrefix,
      'honorificSuffix': instance.honorificSuffix,
      'salutation': instance.salutation,
      'preferredName': instance.preferredName,
    };
