import 'package:json_annotation/json_annotation.dart';

part 'party_greeting_message.g.dart';

// it server as request model for many auth related apis
@JsonSerializable(includeIfNull: false)
class PartyModel {
  PartyModel({
    this.partyId,
    this.partytype,
    this.personalDetail,
  });

  @JsonKey(name: "partyId")
  String? partyId;
  @JsonKey(name: "partytype")
  String? partytype;
  @JsonKey(name: "personalDetail")
  PersonalDetail? personalDetail;

  factory PartyModel.fromJson(Map<String, dynamic> json) =>
      _$PartyModelFromJson(json);

  Map<String, dynamic> toJson() => _$PartyModelToJson(this);
}

@JsonSerializable()
class PersonalDetail {
  PersonalDetail({
    this.firstName,
    this.middleName,
    this.lastName,
    this.honorificPrefix,
    this.honorificSuffix,
    this.salutation,
    this.preferredName,
  });

  String? firstName;
  dynamic middleName;
  String? lastName;
  String? honorificPrefix;
  String? honorificSuffix;
  String? salutation;
  String? preferredName;

  factory PersonalDetail.fromJson(Map<String, dynamic> json) =>
      _$PersonalDetailFromJson(json);

  Map<String, dynamic> toJson() => _$PersonalDetailToJson(this);
}
