import 'package:json_annotation/json_annotation.dart';

part 'auth.g.dart';

// it server as request model for many auth related apis
@JsonSerializable(includeIfNull: false)
class AuthResponse {
  @JsonKey(name: 'partyId', disallowNullValue: true)
  String partyId;
  @JsonKey(name: 'partyType')
  String? partyType;

  AuthResponse({required this.partyId, required this.partyType});

  factory AuthResponse.fromJson(Map<String, dynamic> json) =>
      _$AuthResponseFromJson(json);
}

@JsonSerializable(includeIfNull: false)
class AuthRequest {
  @JsonKey(name: 'username')
  String username;
  @JsonKey(name: 'password')
  String? password;

  AuthRequest({required this.username, this.password});

  Map<String, dynamic> toJson() => _$AuthRequestToJson(this);
}
