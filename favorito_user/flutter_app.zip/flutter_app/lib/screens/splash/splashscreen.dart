import 'dart:async';
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:qovarian/app/bloc/app_bloc.dart';
import 'package:qovarian/app/bloc/qovarian_app_data.dart';
import 'package:qovarian/screens/auth/login_page.dart';
import 'package:qovarian/screens/home/home_screen.dart';

enum CustomSplashType { StaticDuration, BackgroundProcess }

class Splash extends StatefulWidget {
  final Widget home;
  final int? duration;
  final Color? backGroundColor;
  final String animationEffect;
  final double logoSize;

  Splash(
      {required this.home,
      this.duration,
      this.backGroundColor,
      this.animationEffect = 'fade-in',
      this.logoSize = 80.0}) {
    assert(duration != null);
  }

  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  Animation? _animation;
  int? _duration;
  late Timer _timer;
  late QovarianAppBloc appBloc;
  StreamSubscription<AppViewState>? streamSubscription;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIOverlays([SystemUiOverlay.bottom]);
    _duration = (widget.duration! < 1000) ? 2000 : widget.duration;
    _animationController = new AnimationController(
        vsync: this, duration: Duration(milliseconds: 1200));
    _animation = Tween(begin: 0.0, end: 1.0).animate(CurvedAnimation(
        parent: _animationController, curve: Curves.easeInCirc));
    _animationController.forward();
    _timer = Timer(Duration(milliseconds: _duration!), () {
      // navigator();
    });
  }

  @override
  void didChangeDependencies() {
    appBloc = Provider.of<QovarianAppBloc>(context);
    streamSubscription = appBloc.appViewStateStream.listen((value) {
      navigator();
    });
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    _animationController.reset();
    _timer.cancel();
    streamSubscription?.cancel();
    super.dispose();
  }

  navigator() async {
    var appViewState = QovarianAppData().viewState;

    switch (appViewState) {
      case AppViewState.shouldLogIn:
        Navigator.of(context).pushReplacement(
            CupertinoPageRoute(builder: (BuildContext context) => LoginPage()));
        break;
      case AppViewState.allOk:
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => HomeScreen()));
        break;
      case AppViewState.profileUpdate:
        // TODO: Handle this case.
        break;
      case AppViewState.none:
        break;
      case AppViewState.forceUpdate:
        // TODO: Handle this case.
        break;
      case AppViewState.sessionTimeout:
        // TODO: Handle this case.
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      child: Stack(
        children: <Widget>[
          Center(
            child: Container(
              margin: EdgeInsets.only(bottom: 80),
              child: Text("QOVARIAN",
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 32,
                      color: Colors.black.withOpacity(0.65))),
            ),
          ),
        ],
      ),
    ));
  }
}
