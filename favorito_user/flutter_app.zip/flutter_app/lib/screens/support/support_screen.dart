import 'package:flutter/material.dart';

class SupportScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _SupportScreenState();
  }
}

class _SupportScreenState extends State<SupportScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(top: 20),
      child: Center(
        child: Text(
          "Coming soon",
          style: TextStyle(fontSize: 16),
        ),
      ),
    );
  }
}
