import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:qovarian/utils/common_colors.dart';

class CarouselCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Container(
      height: size.height * 0.42,
      width: size.width * 0.66,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: borderColor)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            "Store and Rewards",
            style: GoogleFonts.montserrat(
                textStyle: TextStyle(
                    color: highlightedText, fontSize: size.width * 0.05)),
          ),
          Container(
            height: size.height * 0.18,
            width: size.width * 0.58,
            decoration: BoxDecoration(
                color: blankSpace, border: Border.all(color: borderColor)),
          ),
          Container(
            height: size.height * 0.076,
            width: size.width * 0.56,
            child: Text(
              "Let’s get sticky our rewards xcepteur sint occaecat cupidatat non proident.",
              style: GoogleFonts.montserrat(
                  textStyle: TextStyle(
                      color: normalText, fontSize: size.width * 0.04)),
            ),
          ),
          Container(
            height: size.height * 0.04,
            width: size.width * 0.56,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: borderColor)),
            child: TextButton(
                style: ButtonStyle(
                    overlayColor:
                        MaterialStateColor.resolveWith((states) => blankSpace)),
                onPressed: () {},
                child: Text(
                  "Change Settings",
                  textAlign: TextAlign.center,
                  style: GoogleFonts.montserrat(
                      color: highlightedText, fontSize: size.width * 0.035),
                )),
          )
        ],
      ),
    );
  }
}
