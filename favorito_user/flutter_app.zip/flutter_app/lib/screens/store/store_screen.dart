import 'package:carousel_slider/carousel_options.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:qovarian/screens/store/carousel_card.dart';
import 'package:qovarian/utils/common_colors.dart';
import 'package:qovarian/widgets/bottom_common_widget.dart';

class StoreScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _StoreScreenState();
  }
}

class _StoreScreenState extends State<StoreScreen> {
  int _current = 0;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      color: Colors.white,
      height: size.height,
      width: size.width,
      margin: EdgeInsets.symmetric(vertical: 10),
      child: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: size.height * 0.58,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  CarouselSlider.builder(
                      itemCount: 5,
                      itemBuilder: (context, index, realIndex) {
                        return CarouselCard();
                      },
                      options: CarouselOptions(
                          initialPage: 0,
                          viewportFraction: 0.7,
                          enableInfiniteScroll: false,
                          autoPlay: false,
                          enlargeCenterPage: true,
                          height: size.height * 0.52,
                          onPageChanged: (index, reason) {
                            setState(() {
                              _current = index;
                            });
                          })),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      indicatorOfCarousel(0),
                      indicatorOfCarousel(1),
                      indicatorOfCarousel(2),
                      indicatorOfCarousel(3),
                      indicatorOfCarousel(4)
                    ],
                  )
                ],
              ),
            ),
            SizedBox(
              height: 60,
            ),
            BottomCommonSheet()
          ],
        ),
      ),
    );
  }

  Widget indicatorOfCarousel(int index) {
    return Container(
      width: 8.0,
      height: 8.0,
      margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 2.0),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: borderColor),
        color: _current == index ? blankSpace : Colors.white,
      ),
    );
  }
}
