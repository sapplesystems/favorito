import 'package:flutter/material.dart';

class CardWidget extends StatefulWidget {
  final String? title, subtitle;
  CardWidget({this.title, this.subtitle});
  @override
  _CardWidgetState createState() => _CardWidgetState();
}

class _CardWidgetState extends State<CardWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey,
        border: Border.all(width: 1.0),
        borderRadius: BorderRadius.all(
            Radius.circular(10) //                 <--- border radius here
            ),
      ),
      child: Padding(
        padding:
            const EdgeInsets.only(top: 18.0, bottom: 50, left: 13, right: 14),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    widget.title!,
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
                    textAlign: TextAlign.start,
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.grey,
                    border: Border.all(width: 1.0),
                    borderRadius: BorderRadius.all(Radius.circular(
                            5) //                 <--- border radius here
                        ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.only(
                        left: 18, right: 18, top: 5, bottom: 5),
                    child: Text(
                      "Filter",
                      style:
                          TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                      textAlign: TextAlign.start,
                    ),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 18),
              child: Text(
                widget.subtitle!,
                style: TextStyle(fontSize: 15),
                textAlign: TextAlign.start,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
