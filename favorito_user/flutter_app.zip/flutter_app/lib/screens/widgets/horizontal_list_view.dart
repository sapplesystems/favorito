import 'package:flutter/material.dart';

class HorizontalListViewWidget extends StatefulWidget {
  final List<String>? horizontalListViewTitle;
  HorizontalListViewWidget({this.horizontalListViewTitle});
  @override
  _HorizontalListViewWidgetState createState() =>
      _HorizontalListViewWidgetState();
}

class _HorizontalListViewWidgetState extends State<HorizontalListViewWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      //padding: EdgeInsets.only(top: 3),
      height: 80,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: widget.horizontalListViewTitle!.length,
        itemBuilder: (context, i) {
          return Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: Container(
              width: 80,
              decoration: BoxDecoration(
                color: Colors.grey,
                border: Border.all(width: 1.0),
                borderRadius: BorderRadius.all(Radius.circular(
                        5.0) //                 <--- border radius here
                    ),
              ),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "${widget.horizontalListViewTitle![i]}",
                    style: TextStyle(fontSize: 12),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
    /*Container(
      padding: EdgeInsets.only(top: 3),
      height: 80,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: Container(
              width: 80,
              decoration: BoxDecoration(
                color: Colors.grey,
                border: Border.all(width: 1.0),
                borderRadius: BorderRadius.all(Radius.circular(
                        5.0) //                 <--- border radius here
                    ),
              ),
              child: Center(
                child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Text("Mercedes F1")),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: Container(
              width: 80,
              decoration: BoxDecoration(
                color: Colors.grey,
                border: Border.all(width: 1.0),
                borderRadius: BorderRadius.all(Radius.circular(
                        5.0) //                 <--- border radius here
                    ),
              ),
              child: Center(
                child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Text("Mercedes F1")),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: Container(
              width: 80,
              decoration: BoxDecoration(
                color: Colors.grey,
                border: Border.all(width: 1.0),
                borderRadius: BorderRadius.all(Radius.circular(
                        5.0) //                 <--- border radius here
                    ),
              ),
              child: Center(
                child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Text("Mercedes F1")),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: Container(
              width: 80,
              decoration: BoxDecoration(
                color: Colors.grey,
                border: Border.all(width: 1.0),
                borderRadius: BorderRadius.all(Radius.circular(
                        5.0) //                 <--- border radius here
                    ),
              ),
              child: Center(
                child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Text("Mercedes F1")),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: Container(
              width: 80,
              decoration: BoxDecoration(
                color: Colors.grey,
                border: Border.all(width: 1.0),
                borderRadius: BorderRadius.all(Radius.circular(
                        5.0) //                 <--- border radius here
                    ),
              ),
              child: Center(
                child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Text("Mercedes F1")),
              ),
            ),
          ),
        ],
      ),
    );*/
  }
}
