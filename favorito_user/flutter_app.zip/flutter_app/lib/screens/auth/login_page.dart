import 'package:flutter/material.dart';
import 'package:flutter_html/shims/dart_ui_real.dart';
import 'package:provider/provider.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/screens/auth/login_bloc.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:qovarian/screens/home/home_screen.dart';
import 'package:qovarian/usecases/app_general.dart';

class LoginPage extends StatefulWidget {
  static String routeName = "auth/login_page";

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController email = TextEditingController();
  final TextEditingController password = TextEditingController();

  LoginBloc bloc = LoginBloc();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return ListenableProvider.value(
      value: bloc,
      child: Scaffold(
        backgroundColor: Color(0xFF343A40),
        body: Center(
          child: Material(
            child: Container(
              alignment: Alignment.center,
              color: Color(0xFF343A40),
              height: size.height * 0.5,
              width: size.width,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      alignment: Alignment.center,
                      child: Text(
                        "${AppLocalizations.of(context)!.login}",
                        style: TextStyle(
                            fontSize: size.width * 0.06, color: Colors.white),
                      ),
                      height: size.height * 0.1,
                      width: size.width * 0.5,
                    ),
                    EnteringField(
                      icon: Icons.person,
                      controller: email,
                      keyboardType: TextInputType.emailAddress,
                      isPassword: false,
                      textInputAction: TextInputAction.next,
                      validation: (_) {},
                    ),
                    SizedBox(
                      height: 16,
                    ),
                    EnteringField(
                        icon: Icons.lock,
                        controller: password,
                        keyboardType: TextInputType.visiblePassword,
                        isPassword: true,
                        validation: (password) =>
                            bloc.passwordValidator(password)),
                    SizedBox(
                      height: 36,
                    ),
                    TextButton(
                        onPressed: () async {
                          await login(context);
                        },
                        style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all(
                          Colors.black45,
                        )),
                        child: Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 18, vertical: 10),
                          child: Text(
                            "${AppLocalizations.of(context)!.login}",
                            style: TextStyle(color: Colors.white, fontSize: 18),
                          ),
                        )),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> login(BuildContext context) async {
    try {
      if (await bloc.login(email.text, password.text)) {
        Navigator.pushReplacementNamed(context, HomeScreen.routeName);
      }
    } on QHttpException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(e.detail, style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.black,
      ));
    }
  }
}

class EnteringField extends StatefulWidget {
  final bool isPassword;
  final String label;
  final TextInputAction textInputAction;
  final TextEditingController controller;
  final TextInputType? keyboardType;

  final String? Function(String?)? validation;
  final IconData icon;

  EnteringField(
      {Key? key,
      this.isPassword = false,
      required this.icon,
      required this.keyboardType,
      this.textInputAction = TextInputAction.done,
      required this.controller,
      this.label = "",
      required this.validation})
      : super(key: key);

  @override
  _EnteringFieldState createState() => _EnteringFieldState();
}

class _EnteringFieldState extends State<EnteringField> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      padding: EdgeInsets.symmetric(
          vertical: size.height * 0.01, horizontal: size.width * 0.04),
      width: size.width * 0.8,
      child: Container(
        width: size.width * 0.5,
        child: TextFormField(
          autovalidateMode: AutovalidateMode.onUserInteraction,
          controller: widget.controller,
          textInputAction: widget.textInputAction,
          obscureText: widget.isPassword,
          keyboardType: widget.keyboardType,
          validator: widget.validation,
          style: TextStyle(
            fontSize: size.width * 0.05,
            color: Colors.white,
          ),
          decoration: InputDecoration(
              contentPadding: EdgeInsets.only(bottom: size.height * 0.02),
              prefixIcon: Icon(
                widget.icon,
                color: Colors.white,
              ),
              labelText: widget.label,
              focusColor: Colors.white,
              errorBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.red)),
              enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.white)),
              focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.white)),
              border: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.white))),
        ),
      ),
    );
  }
}
