import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:qovarian/app/bloc/qovarian_app_data.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/models/auth.dart';
import 'package:qovarian/usecases/app_general.dart';
import 'package:qovarian/usecases/auth_usecases.dart';
import 'package:qovarian/utils/email_validator.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class LoginBloc extends ChangeNotifier {
  String? emailValidator(String? email, context) {
    if (email != null) {
      if (email.isNotEmpty) {
        if (EmailValidator.validate(email)) {
          return null;
        } else {
          return "${AppLocalizations.of(context)!.notValidEmail}";
        }
      } else {
        return '${AppLocalizations.of(context)!.noEmailWritten}';
      }
    }
  }

  String? passwordValidator(String? password) {
    num minLength = 8;
    if (password == null) {
      return null;
    } else {
      if (password.isNotEmpty) {
        if (password.length < 6) return "Password must be atleast 6 characters";
        if (password.length > 12)
          return "Passowrd cannot be more than 12 characters";
        if (!password.contains(RegExp(r"[A-Z]")))
          return "Password must have atleast 1 Uppercase letter";
        if (!password.contains(RegExp(r"[a-z]")))
          return "Password must have atleast 1 Lowercase letter";
        if (!password.contains(RegExp(r"[0-9]")))
          return "Password must have atleast 1 numeric character";
        if (!password.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]')))
          return "Password must have atleast 1 special character";
      } else {
        return 'Password is necessary';
      }
    }
  }

  Future<bool> login(String userName, String password) async {
    try {
      AuthResponse authResponse = await LoginUseCase(
              AuthRequest(username: userName, password: password))
          .execute();
      SaveUid(authResponse.partyId).execute();
      QovarianAppData().viewState = AppViewState.allOk;
      return true;
    } on QHttpException catch (e) {
      throw e;
    }
  }
}
