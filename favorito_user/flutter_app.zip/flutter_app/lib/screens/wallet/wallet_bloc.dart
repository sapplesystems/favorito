import 'package:flutter/cupertino.dart';

enum viewType { grid, list }

class ViewBloc extends ChangeNotifier {
  viewType view = viewType.list;

  void onChanged(viewType type) {
    view = type;
    notifyListeners();
  }
}
