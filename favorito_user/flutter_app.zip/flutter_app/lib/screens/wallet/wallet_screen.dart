import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qovarian/screens/home/home_screen.dart';
import 'package:qovarian/screens/wallet/list_view_wallet.dart';
import 'package:qovarian/screens/wallet/wallet_bloc.dart';
import 'package:qovarian/utils/common_colors.dart';

class WalletScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _WalletScreenState();
  }
}

class _WalletScreenState extends State<WalletScreen> {
  int _current = 0;
  ViewBloc _viewBloc = ViewBloc();

  @override
  Widget build(BuildContext context) {
    return ListView(
        padding: EdgeInsets.symmetric(
          horizontal: 16,
        ),
        children: [
          ChangeNotifierProvider<ViewBloc>.value(
            value: _viewBloc,
            child: Container(
              height: 520,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Consumer<ViewBloc>(builder: (_, viewBloc, __) {
                    return (viewBloc.view == viewType.grid)
                        ? CarouselSlider.builder(
                            itemCount: 5,
                            itemBuilder: (context, index, realIndex) {
                              return AccountsCard();
                            },
                            options: CarouselOptions(
                                initialPage: 0,
                                viewportFraction: 1,
                                enableInfiniteScroll: false,
                                autoPlay: false,
                                enlargeCenterPage: true,
                                enlargeStrategy:
                                    CenterPageEnlargeStrategy.scale,
                                height: 490,
                                onPageChanged: (index, reason) {
                                  setState(() {
                                    _current = index;
                                  });
                                }))
                        : ListCard();
                  }),
                  Consumer<ViewBloc>(builder: (_, viewBloc, __) {
                    return (viewBloc.view == viewType.grid)
                        ? Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              indicatorOfCarousel(0),
                              indicatorOfCarousel(1),
                              indicatorOfCarousel(2),
                              indicatorOfCarousel(3),
                              indicatorOfCarousel(4)
                            ],
                          )
                        : Container();
                  }),
                ],
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 40),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  child: Text(
                    "Manage Wallet",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                ),
                SizedBox(
                  height: 16,
                ),
                Container(
                  height: 80,
                  child: HorizontalListView(
                    cardNames: ["Pay & transfer", "Pots", "Tickets", "Loyalty"],
                  ),
                ),
              ],
            ),
          )
        ]);
  }

  Widget indicatorOfCarousel(int index) {
    return Container(
      width: 8.0,
      height: 8.0,
      margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 2.0),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: Colors.black45),
        color: _current == index ? blankSpace : Colors.white,
      ),
    );
  }
}

class AccountsCard extends StatelessWidget {
  AccountsCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<ViewBloc>(builder: (_, _viewBloc, __) {
      return Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
                color: (_viewBloc.view == viewType.grid)
                    ? borderColor
                    : Colors.transparent)),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            buildHeader(),
            buildMiddle(context),
            (_viewBloc.view == viewType.grid)
                ? Expanded(child: buildBottomSection())
                : ListViewWidgets.secondBox(_),
          ],
        ),
      );
    });
  }

  Widget buildMiddle(context) {
    return Consumer<ViewBloc>(builder: (_, viewBloc, __) {
      return (viewBloc.view == viewType.grid)
          ? Container(
              height: 180,
              margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: Colors.grey)),
            )
          : ListViewWidgets.firstBox(context);
    });
  }

  Container buildHeader() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Consumer<ViewBloc>(
        builder: (_, viewBloc, __) {
          return Row(
            children: [
              Expanded(
                child: (viewBloc.view == viewType.grid)
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Spending pot",
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                          Text("Saving pot")
                        ],
                      )
                    : Text(
                        "Total Account Balance",
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      (viewBloc.view == viewType.grid) ? "\$1500" : "\£2590.00",
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    Text((viewBloc.view == viewType.grid) ? "\$500" : ""),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 8),
                padding: EdgeInsets.all(3),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: borderColor)),
                child: Row(
                  children: [
                    InkWell(
                      onTap: () => viewBloc.onChanged(viewType.grid),
                      child: Icon(Icons.call_to_action),
                    ),
                    InkWell(
                      onTap: () => viewBloc.onChanged(viewType.list),
                      child: Icon(Icons.calendar_view_day),
                    ),
                  ],
                ),
              )
            ],
          );
        },
      ),
    );
  }

  Widget buildBottomSection() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: DefaultTabController(
        length: 3,
        child: Column(
          children: [
            Container(
              child: TabBar(
                indicator: UnderlineTabIndicator(
                    borderSide: BorderSide(color: Colors.black)),
                labelStyle: TextStyle(fontSize: 10, color: Colors.black),
                labelColor: Colors.black,
                labelPadding: EdgeInsets.zero,
                indicatorSize: TabBarIndicatorSize.label,
                tabs: [
                  Tab(
                    text: "Transactions",
                  ),
                  Tab(
                    text: "Pay & Transfer",
                  ),
                  Tab(
                    text: "My card",
                  ),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                children: [
                  TransactionView(),
                  Center(child: Text("Coming soon")),
                  Center(child: Text("Coming soon")),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

class ListCard extends StatelessWidget {
  ListCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<ViewBloc>(builder: (_, _viewBloc, __) {
      return Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            border: Border.all(
                color: (_viewBloc.view == viewType.grid)
                    ? borderColor
                    : Colors.transparent)),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            buildHeader(),
            buildMiddle(context),
            (_viewBloc.view == viewType.grid)
                ? Expanded(child: buildBottomSection())
                : ListViewWidgets.secondBox(_),
          ],
        ),
      );
    });
  }

  Widget buildMiddle(context) {
    return Consumer<ViewBloc>(builder: (_, viewBloc, __) {
      return (viewBloc.view == viewType.grid)
          ? Container(
              height: 180,
              margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: Colors.grey)),
            )
          : ListViewWidgets.firstBox(context);
    });
  }

  Container buildHeader() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Consumer<ViewBloc>(
        builder: (_, viewBloc, __) {
          return Row(
            children: [
              Expanded(
                child: (viewBloc.view == viewType.grid)
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Spending pot",
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                          Text("Saving pot")
                        ],
                      )
                    : Text(
                        "Total Account Balance",
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      (viewBloc.view == viewType.grid) ? "\$1500" : "\£2590.00",
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    Text((viewBloc.view == viewType.grid) ? "\$500" : ""),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(left: 8),
                padding: EdgeInsets.all(3),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: borderColor)),
                child: Row(
                  children: [
                    InkWell(
                      onTap: () => viewBloc.onChanged(viewType.grid),
                      child: Icon(Icons.call_to_action),
                    ),
                    InkWell(
                      onTap: () => viewBloc.onChanged(viewType.list),
                      child: Icon(Icons.calendar_view_day),
                    ),
                  ],
                ),
              )
            ],
          );
        },
      ),
    );
  }

  Widget buildBottomSection() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: DefaultTabController(
        length: 3,
        child: Column(
          children: [
            Container(
              child: TabBar(
                indicator: UnderlineTabIndicator(
                    borderSide: BorderSide(color: Colors.black)),
                labelStyle: TextStyle(fontSize: 10, color: Colors.black),
                labelColor: Colors.black,
                labelPadding: EdgeInsets.zero,
                indicatorSize: TabBarIndicatorSize.label,
                tabs: [
                  Tab(
                    text: "Transactions",
                  ),
                  Tab(
                    text: "Pay & Transfer",
                  ),
                  Tab(
                    text: "My card",
                  ),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                children: [
                  TransactionView(),
                  Center(child: Text("Coming soon")),
                  Center(child: Text("Coming soon")),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

class TransactionView extends StatelessWidget {
  const TransactionView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: ListView(
            children: [
              listItem("Today spend"),
              listItem("Yesterday spend"),
              listItem("23 jun 2021"),
              listItem("21 jun 2021"),
              Material(
                  child: InkWell(
                splashColor: Colors.black12,
                onTap: () {
                  showModalBottomSheet(
                      context: context,
                      builder: (context) {
                        return Container(
                          child: Center(
                            child: Text("coming soon"),
                          ),
                        );
                      });
                },
                child: Container(
                  alignment: AlignmentDirectional.center,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Spending and details"),
                      SizedBox(
                        width: 16,
                      ),
                      Icon(Icons.keyboard_arrow_down),
                    ],
                  ),
                ),
              ))
            ],
          ),
        ),
      ],
    );
  }

  Container listItem(String title) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [Expanded(child: Text(title)), Text("\$500")],
      ),
    );
  }
}
