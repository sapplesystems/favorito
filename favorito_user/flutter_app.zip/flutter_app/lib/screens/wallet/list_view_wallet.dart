import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:qovarian/generated/l10n.dart';
import 'package:qovarian/utils/common_colors.dart';

class ListViewWidgets {
  static Widget firstBox(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: size.height * 0.25,
      width: size.width,
      margin: EdgeInsets.only(bottom: 12),
      padding: EdgeInsets.symmetric(vertical: 10),
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            AccountBox(
              accBal: 2590,
              accNo: 1,
            ),
            TextButton(
                onPressed: () {},
                child: Text(
                  "Open new account +",
                  style: GoogleFonts.montserrat(color: highlightedText),
                ))
          ],
        ),
      ),
    );
  }

  static Widget secondBox(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: size.height * 0.25,
      width: size.width,
      padding: EdgeInsets.symmetric(vertical: 10),
      margin: EdgeInsets.only(top: 2),
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 12.0),
                  child: Text(
                    "Total Pot Balance",
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(right: 12.0),
                  child: Text("\£ 2589"),
                )
              ],
            ),
            PotBox(
              potBal: 2590,
              potNo: 1,
            ),
            TextButton(
                onPressed: () {},
                child: Text(
                  "Open new account +",
                  style: GoogleFonts.montserrat(color: highlightedText),
                ))
          ],
        ),
      ),
    );
  }
}

class AccountBox extends StatelessWidget {
  int accNo, accBal;
  AccountBox({this.accNo = 1, this.accBal = 0});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: size.height * 0.15,
      width: size.width,
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            decoration: BoxDecoration(
                color: blankSpace,
                borderRadius: BorderRadius.all(Radius.circular(16))),
            height: size.height * 0.1,
            width: size.width * 0.24,
            margin: EdgeInsets.symmetric(horizontal: 13, vertical: 5),
          ),
          Expanded(
            child: Text(
              "Utkarsh $accNo : \£ $accBal",
              style: GoogleFonts.montserrat(),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: size.width * 0.15),
            child: Icon(
              CupertinoIcons.forward,
              color: Color(0xFF000000),
            ),
          )
        ],
      ),
    );
  }
}

class PotBox extends StatelessWidget {
  int potNo, potBal;
  PotBox({this.potNo = 1, this.potBal = 0});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: size.height * 0.15,
      width: size.width,
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            decoration: BoxDecoration(
                color: blankSpace,
                borderRadius: BorderRadius.all(Radius.circular(16))),
            height: size.height * 0.1,
            width: size.width * 0.24,
            margin: EdgeInsets.symmetric(horizontal: 13, vertical: 5),
          ),
          Padding(
            padding: EdgeInsets.only(top: 24.0),
            child: Column(
              children: [
                Text(
                  "Home Pot $potNo",
                  style: GoogleFonts.montserrat(),
                ),
                Text(
                  "\£ $potBal",
                  style: GoogleFonts.montserrat(),
                )
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: size.width * 0.15),
            child: Icon(
              CupertinoIcons.forward,
              color: Color(0xFF000000),
            ),
          )
        ],
      ),
    );
  }
}
