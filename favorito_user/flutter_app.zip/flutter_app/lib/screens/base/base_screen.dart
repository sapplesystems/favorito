import 'dart:ui';

import 'package:flutter/material.dart';

extension BaseState<T extends StatefulWidget> on State<T> {

  void showError(
      { String msg = " ",
      int seconds = 2,
      required int statusCode,
      BuildContext? buildContext}) {
    ScaffoldMessenger.of(buildContext ?? context).showSnackBar(
      SnackBar(
        content: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(
                top: 4,
                bottom: 4,
              ),
              child: Text(
                msg ,
                style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.white,
                    fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }

}

mixin QBaseStateMixin<T extends StatefulWidget> on State<T> {}
