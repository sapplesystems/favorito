import 'package:qovarian/usecases/app_general.dart';

class PaginatedLoading {}

class PaginatedError {}

class PaginatedRetry {}

class PaginatedEmpty {}

abstract class BlocEvent {}

abstract class BlocState {
  BlocState({this.exception});

  QHttpException? exception;
}

abstract class BlocBase {
  void dispose();
}
