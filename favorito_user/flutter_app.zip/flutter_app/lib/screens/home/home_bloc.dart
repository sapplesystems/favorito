import 'package:flutter/foundation.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/models/app.dart';
import 'package:qovarian/models/auth.dart';
import 'package:qovarian/models/party_greeting_message.dart';
import 'package:qovarian/usecases/app_general.dart';
import 'package:qovarian/usecases/greeting_message_usecases.dart';

class HomeBloc extends ChangeNotifier {
  PartyModel? partyData;

  void init() async {
    String partyId = (await GetUid().execute())!;
    getParty(partyId);
  }

  Future<void> getParty(String partyId) async {
    try {
      partyData = await GetPartyUseCase(partyId).execute();
      notifyListeners();
    } on QHttpException catch (e) {
      Log.e(e);
      // handle
    }
  }
}
