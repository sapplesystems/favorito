import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qovarian/screens/auth/login_page.dart';
import 'package:qovarian/screens/home/home_bloc.dart';
import 'package:qovarian/screens/search/search_screen.dart';
import 'package:qovarian/screens/store/store_screen.dart';
import 'package:qovarian/screens/support/support_screen.dart';
import 'package:qovarian/screens/wallet/wallet_screen.dart';
import 'package:qovarian/usecases/app_general.dart';
import 'package:qovarian/widgets/bottom_common_widget.dart';

class HomeScreen extends StatefulWidget {
  static String routeName = "home_screen";

  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late HomeBloc bloc;
  int _selectedIndex = 2;
  static List<Widget> _widgetOptions = <Widget>[
    SearchScreen(),
    WalletScreen(),
    HomePageContent(),
    StoreScreen(),
    SupportScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  void initState() {
    super.initState();
    bloc = HomeBloc();
    bloc.init();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: bloc,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(child: greetingMessageWidget("", context)),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: TextButton(
                        onPressed: () {
                          logout();
                        },
                        child: Text("Logout")),
                  )
                ],
              ),
              Expanded(child: _widgetOptions.elementAt(_selectedIndex))
            ],
          ),
        ),
        bottomNavigationBar: QBottomNavigationBar(
          selectedIndex: _selectedIndex,
          onTap: _onItemTapped,
        ),
      ),
    );
  }

  Widget greetingMessageWidget(String message, context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16),
      margin: EdgeInsets.symmetric(vertical: 8),
      child: Consumer<HomeBloc>(
        builder: (context, bloc, child) {
          return Text(
            "Hi ${getGreetingMessage(bloc)} , Good morning",
            style: TextStyle(fontWeight: FontWeight.w600),
          );
        },
      ),
    );
  }

  String getGreetingMessage(HomeBloc bloc) {
    var message = bloc.partyData?.personalDetail!;
    return message != null
        ? checkMessageIsEmpty(message.preferredName!)
            ? checkMessageIsEmpty(message.salutation!)
                ? message.firstName!
                : message.salutation!
            : message.preferredName!
        : "";
  }

  bool checkMessageIsEmpty(String message) {
    return ((message.isEmpty) || (message == null)) ? true : false;
  }

  void logout() async {
    await ClearUid().execute();
    Navigator.popUntil(context, (route) => route.isFirst);
    Navigator.of(context).pushReplacement(
        CupertinoPageRoute(builder: (BuildContext context) => LoginPage()));
  }
}

class HomePageContent extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _HomePageContentState();
  }
}

class _HomePageContentState extends State<HomePageContent> {
  List<String> homeScreenHorizontalLiatViewTitle = <String>[
    "Mercedes F1",
    "Rainforest Alliance",
    "Saved Insights",
    "Change settings"
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
        padding: EdgeInsets.symmetric(
          horizontal: 16,
        ),
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 18),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    height: 236,
                    color: Color(0xffD8D8D8),
                  ),
                )
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Text(
              "Talk to Lewis talks about fashion, music, racisim, money and electric cars",
              style: TextStyle(fontSize: 16),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(top: 40),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  child: Text(
                    "My Mercedes",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                ),
                SizedBox(
                  height: 16,
                ),
                Container(
                  height: 80,
                  child: HorizontalListView(cardNames:homeScreenHorizontalLiatViewTitle,),
                ),
                SizedBox(
                  height: 24,
                ),
                BottomCommonSheet()
              ],
            ),
          )
        ]);
  }
}

class HorizontalListView extends StatelessWidget {
  final List<String> cardNames;

  const HorizontalListView({Key? key, required this.cardNames})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
      scrollDirection: Axis.horizontal,
      children: List.generate(
          cardNames.length, (index) => getCardContainer(cardNames[index])),
    );
  }

  Widget getCardContainer(String cardName) {
    return Container(
      width: 80,
      margin: EdgeInsets.only(right: 12),
      alignment: AlignmentDirectional.bottomCenter,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: Colors.grey)),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 6),
        child: Text(
          cardName,
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

class QBottomNavigationBar extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int>? onTap;

  const QBottomNavigationBar({Key? key, this.selectedIndex = 2, this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    var bottomItemBackgroundColor = Colors.white;
    return Container(
      child: BottomNavigationBar(
        backgroundColor: Colors.black,
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: bottomBarIcon(Icons.search),
            label: "Search",
            backgroundColor: bottomItemBackgroundColor,
          ),
          BottomNavigationBarItem(
              icon: bottomBarIcon(Icons.wallet_giftcard_rounded),
              label: "Wallet",
              backgroundColor: bottomItemBackgroundColor),
          BottomNavigationBarItem(
            icon: bottomBarIcon(Icons.home, 36),
            label: "Home",
            backgroundColor: bottomItemBackgroundColor,
          ),
          BottomNavigationBarItem(
            icon: bottomBarIcon(Icons.store),
            label: "Store",
            backgroundColor: bottomItemBackgroundColor,
          ),
          BottomNavigationBarItem(
            icon: bottomBarIcon(Icons.support),
            label: "Support",
            backgroundColor: bottomItemBackgroundColor,
          ),
        ],
        type: BottomNavigationBarType.shifting,
        currentIndex: selectedIndex,
        selectedItemColor: Colors.black,
        showUnselectedLabels: true,
        unselectedLabelStyle: TextStyle(fontSize: 15),
        unselectedFontSize: 15,
        selectedFontSize: 15,
        iconSize: 35,
        onTap: onTap,
      ),
    );
  }

  Widget bottomBarIcon(IconData iconData, [double? size]) {
    return Icon(
      iconData,
      size: size ?? 24,
      color: Colors.black,
    );
  }
}
