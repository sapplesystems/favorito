class UserDao {
  const UserDao();
}
