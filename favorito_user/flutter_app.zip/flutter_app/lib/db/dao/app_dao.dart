class AppDao {
  const AppDao();
}
