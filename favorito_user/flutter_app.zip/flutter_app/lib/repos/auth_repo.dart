import 'dart:async';

import 'package:dio/dio.dart';
import 'package:qovarian/services/networkservices.dart';

class AuthRepo {
  static final ApiClient apiClient = ApiClient();

  const AuthRepo();

  Future<Response<T>> loginRequest<T>(path, Map<String, dynamic> loginData) async {
    var base = Uri.parse("http://a0411fd6b21b849afb3df1834884693b-783904198.eu-west-2.elb.amazonaws.com");
    RequestOptions options =
        apiClient.getAppNoAuthOptions(baseUrl: base.toString(),path: path);
    apiClient.initDio(baseUrl: base.toString());

    return await apiClient.postData<T>(
        path: path, data: loginData, requestOptions: options);
  }

}
