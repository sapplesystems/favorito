import 'dart:async';

import 'package:dio/dio.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/db/dao/user_dao.dart';
import 'package:qovarian/models/app.dart';
import 'package:qovarian/services/networkservices.dart';
import 'package:sqflite/sqflite.dart';

class UserRepo {
  static final UserDao userDao = const UserDao();
  static final ApiClient apiClient = ApiClient();

  const UserRepo();

  Future<UserData?> getUserData({required String uid, Database? db}) async {}

  Future<bool> saveUserData(UserData data, {Database? db}) async {
    return Future.value(true);
  }

  Future<Response<T>> updateUserDataNet<T>(
      String path, Map<String, dynamic> data) async {
    RequestOptions options =
        apiClient.getAppOptions(baseUrl: Config.baseUrl, path: path);
    return await apiClient.updateAuthData<T>(
        path: path, data: data, requestOptions: options);
  }

  Future<Response<T>> getUserDataNet<T>(String path) async {
    RequestOptions options =
        apiClient.getAppOptions(baseUrl: Config.baseUrl, path: path);
    return await apiClient.getData(path: path, requestOptions: options);
  }

  Future<Response<T>> logout<T>(String path) async {
    RequestOptions options =
        apiClient.getAppOptions(baseUrl: Config.baseUrl, path: path);
    return await apiClient.getData(path: path, requestOptions: options);
  }

  Future<Response<T>> postFile<T>(String path, FormData formData) async {
    RequestOptions options =
        apiClient.getAppOptions(baseUrl: Config.baseUrl, path: path);
    return await apiClient.postAuthFileData(
        path: path, formData: formData, requestOptions: options);
  }
}
