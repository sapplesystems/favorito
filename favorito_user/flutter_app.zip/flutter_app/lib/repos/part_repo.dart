import 'dart:async';

import 'package:dio/dio.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/services/networkservices.dart';

class PartyRepo {
  static final ApiClient apiClient = ApiClient();

  const PartyRepo();

  Future<Response<T>> getPartyRequest<T>(
      path, Map<String, dynamic> loginData) async {

    var base = Uri.parse("http://a566be5cadfb9460f9e2e14afa2c9693-1557597163.eu-west-2.elb.amazonaws.com");
    RequestOptions options =
    apiClient.getAppNoAuthOptions(baseUrl: base.toString(),path: path);
    apiClient.initDio(baseUrl: base.toString());

    return await apiClient.getAuthData(path: path, requestOptions: options);
  }
}
