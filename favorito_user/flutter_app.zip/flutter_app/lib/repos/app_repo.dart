import 'package:dio/dio.dart';
import 'package:qovarian/app/configs/build_config.dart';
import 'package:qovarian/services/networkservices.dart';

class AppRepo {
  static final ApiClient apiClient = ApiClient();

  const AppRepo();

  Future<Response<T>> checkAppUpdate<T>(
      String path, Map<String, dynamic> appInfo) async {
    RequestOptions options =
        apiClient.getAppOptions(baseUrl: Config.baseUrl, path: path);
    return await apiClient.postData(
        path: path, data: appInfo, requestOptions: options);
  }
}
